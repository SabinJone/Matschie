package stepDef;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Parent {
	
	public static RequestSpecification request;
	public static Response response;
	public static String sys_id;
	

}
